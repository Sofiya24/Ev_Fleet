document.getElementById('registerForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    const role = document.getElementById('role').value;
    const messageDiv = document.getElementById('message');

    // Validate password match
    if (password !== confirmPassword) {
        messageDiv.textContent = "Passwords do not match!";
        messageDiv.style.color = "red";
        return;
    }

    try {
        const response = await fetch('http://localhost:5000/api/auth/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, email, password, role })
        });

        const data = await response.json();
        if (response.ok) {
            alert("Registration successful!");
            window.location.href = 'login.html';
        } else {
            messageDiv.textContent = data.message;
            messageDiv.style.color = "red";
        }
    } catch (error) {
        console.error('Error:', error);
        messageDiv.textContent = "An error occurred. Please try again later.";
        messageDiv.style.color = "red";
    }
});

// Password strength and matching
const passwordField = document.getElementById('password');
const confirmPasswordField = document.getElementById('confirmPassword');
const strengthMessage = document.getElementById('strengthMessage');
const matchMessage = document.getElementById('matchMessage');

// Password strength indicator
passwordField.addEventListener('input', () => {
    const password = passwordField.value;
    if (password.length < 6) {
        strengthMessage.textContent = 'Weak';
        strengthMessage.style.color = 'red';
    } else if (password.length < 10) {
        strengthMessage.textContent = 'Moderate';
        strengthMessage.style.color = 'orange';
    } else {
        strengthMessage.textContent = 'Strong';
        strengthMessage.style.color = 'green';
    }
});

// Password matching indicator
confirmPasswordField.addEventListener('input', () => {
    if (passwordField.value === confirmPasswordField.value) {
        matchMessage.textContent = 'Passwords match';
        matchMessage.style.color = 'green';
    } else {
        matchMessage.textContent = 'Passwords do not match';
        matchMessage.style.color = 'red';
    }
});
