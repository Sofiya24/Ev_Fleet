document.addEventListener
('DOMContentLoaded', function() 
    {
        const email = document.getElementById('email');
        const emailError = document.getElementById('emailError');
        const forgetForm = document.getElementById('forgetForm');

        forgetForm.addEventListener
        ('submit', function(e) 
            {
                e.preventDefault();
                let valid = true;
                const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!email.value.match(emailPattern)) 
                    {
                        emailError.textContent = "Please enter a valid email.";
                        valid = false;
                    } 
                    else 
                    {
                        emailError.textContent = "";
                    }
                if (valid) 
                    {
                        alert("Reset link sent to your email!");
                        forgetForm.reset();
                    }
            }
        );
    }
);
function checkPassword() {
    var password = document.getElementById("password").value;
    var confirmPassword = document.getElementById("cnfrm-Password").value;
    
    var messageDiv = document.getElementById("message");

    if (password.length < 8) 
        {
           messageDiv.style.color = "red";
           messageDiv.innerHTML= "Password must be at least 8 characters!";
           return false;
        }

        if (password !== confirmPassword) {
            messageDiv.style.color = "red";
            messageDiv.innerHTML = "Password don't match";
            return false; 
        }
        // messageDiv.style.color = "green";
        alert("Registration successful!");
        return true;
}

